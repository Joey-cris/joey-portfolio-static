Ibutang diri ang imong profile photo: profile.jpg (o .png/.webp). Mugawas sa hero ug About.
