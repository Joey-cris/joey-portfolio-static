Dept. of Agriculture / LGU-Malitbog photos. Automatic mugawas sa Experience.
