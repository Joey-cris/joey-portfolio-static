Project screenshots. Ngalan = project id sa data.js (attendance.png, van.png, payroll.png).
