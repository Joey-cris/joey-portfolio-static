Photojournalism photos. Ibutang lang ang mga litrato diri, automatic mugawas. Caption sa photoInfo sa data.js (optional).
