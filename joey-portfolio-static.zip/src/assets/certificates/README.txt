Certificates. Ngalan = file id sa data.js. Ibutang qgis.png para sa QGIS certificate.
