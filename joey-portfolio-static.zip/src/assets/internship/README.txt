Internship photos (Armada Logics). Automatic mugawas sa Experience.
