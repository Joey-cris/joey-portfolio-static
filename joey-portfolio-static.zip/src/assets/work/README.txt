My Work gallery. Prefix sa filename ang category: photography-xxx.jpg, it-xxx.png, web-xxx.png, internship-xxx.jpg
